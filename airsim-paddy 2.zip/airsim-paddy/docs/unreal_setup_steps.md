# Unreal Engine Paddy Field Environment — Setup Steps

## Prerequisites
- Unreal Engine 4.27 installed
- AirSim cloned from GitHub (https://github.com/microsoft/AirSim)
- AirSim built with Visual Studio 2022 (run build.cmd)

---

## Step 1 — Create New Unreal Project

1. Open Epic Games Launcher → Unreal Engine 4.27 → Launch
2. Select: **Games → Blank → No Starter Content**
3. Project name: `PaddyFieldSim`
4. Save to: `C:\Unreal Projects\PaddyFieldSim\`

---

## Step 2 — Add AirSim Plugin

1. Navigate to `C:\Unreal Projects\PaddyFieldSim\`
2. Create folder: `Plugins\`
3. Copy `AirSim\Unreal\Plugins\AirSim\` → `PaddyFieldSim\Plugins\AirSim\`
4. Right-click `PaddyFieldSim.uproject` → **Generate Visual Studio project files**
5. Open `.sln` in VS2022 → Build → run Unreal project

---

## Step 3 — Create Paddy Field Terrain

### 3a. Landscape
1. In Unreal Editor: **Modes → Landscape**
2. Create new landscape: `256 x 256`, flat (no erosion)
3. Apply a **dirt/grass material** to base terrain
4. Keep terrain mostly flat — only slight elevation variation

### 3b. Paddy Field Layout (use BSP Brushes or Planes)
Create the following actors in your level:

| Actor | Type | Details |
|-------|------|---------|
| PaddyPlot_01..12 | StaticMesh Plane | Water + green rice texture |
| FieldBoundary_* | Cube brushes | Narrow mud bunds between plots |
| FarmPath_* | Plane | Brown dirt texture between rows |
| DroneSpawnPoint | Empty Actor | Place at open area, name it exactly this |
| WeedPatch_01..08 | StaticMesh | Yellow-green weed mesh (see Step 4) |
| BP_SprayEffect_0..7 | Blueprint Actor | Particle spray (see Step 5) |

### 3c. Recommended Free Assets (Unreal Marketplace)
Search and add:
- **"Rice Field"** or **"Agricultural Land"** — paddy crop rows
- **"Grass and Weeds"** — weed patches
- **"Water Plane"** — flooded paddy plots
- **"Rural Farm"** — paths and bunds

---

## Step 4 — Weed Object Placement and Tagging

1. Import or create a weed Static Mesh (yellow-green leaf cluster)
2. Place 6–10 instances inside paddy plots at random positions
3. For each weed actor:
   - Name it: `WeedPatch_00`, `WeedPatch_01`, etc.
   - Add Actor Tag: `WeedPatch` (Details Panel → Tags → +)
4. Set weed material to a distinct yellow-green color so color-based detection works

---

## Step 5 — Spray Effect Blueprint (BP_SprayEffect)

1. Content Browser → right-click → **Blueprint Class → Actor**
2. Name it: `BP_SprayEffect`
3. Inside Blueprint:
   - Add component: **Particle System** (or Niagara System)
   - Use particle: `P_Water_Splash` or any spray-type particle
   - Set **Auto Activate = false** (controlled by spray_controller.py)
4. In Event Graph:
   ```
   Event BeginPlay → Set Visibility (Hidden)
   Custom Event "Activate" → Set Visibility (Visible) → Activate (Particle)
   Custom Event "Deactivate" → Deactivate (Particle) → Set Visibility (Hidden)
   ```
5. Place 8 instances in the level: `BP_SprayEffect_0` through `BP_SprayEffect_7`
   - Position doesn't matter — Python script moves them at runtime

---

## Step 6 — Lighting and Sky Setup

1. **World Settings → Game Mode → AirSimGameMode**
2. Delete default Sky Atmosphere or adjust:
   - **Directional Light**: intensity 10, angle 45° (daylight)
   - **Sky Light**: enable, intensity 1.0
   - **Exponential Height Fog**: density 0.02 (light morning haze)
3. Time of day: Set to 10:00 AM look (good visibility for drone camera)

---

## Step 7 — AirSim Settings

Copy `config/settings.json` to:
```
C:\Users\<YourName>\Documents\AirSim\settings.json
```

---

## Step 8 — Run and Test

1. In Unreal Editor → **Play** (or package and run)
2. AirSim will detect the drone spawn point
3. Open terminal:
```bash
cd scripts
pip install -r requirements.txt
python demo.py --visualize
```

---

## Folder Structure Summary

```
PaddyFieldSim/
├── Plugins/AirSim/              ← AirSim plugin
├── Content/
│   ├── Maps/PaddyField.umap     ← Main level
│   ├── Blueprints/
│   │   └── BP_SprayEffect.uasset
│   ├── Materials/
│   │   ├── M_PaddyWater
│   │   ├── M_CropRow
│   │   └── M_Weed
│   └── Meshes/
│       ├── SM_WeedPatch
│       └── SM_FieldBoundary
└── PaddyFieldSim.uproject
```
