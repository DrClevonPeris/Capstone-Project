# Paddy Field Setup Guide — Windows PC

# (Send this to your friend along with the airsim-paddy.zip)

---

## What you need

- Windows 10 or 11 PC with a decent GPU
- ~50 GB free disk space
- Internet connection

---

## STEP 1 — Install Epic Games Launcher (10 min)

1. Go to: https://www.unrealengine.com/en-US/download
2. Download and install Epic Games Launcher
3. Create a free Epic Games account and sign in

---

## STEP 2 — Install Unreal Engine 5.3 (30–60 min)

1. Open Epic Games Launcher
2. Click **Unreal Engine** → **Library**
3. Click the **+** button → select **5.3.0** → click **Install**
4. Wait for download (~30 GB)

---

## STEP 3 — Install Colosseum (AirSim fork) (20 min)

Open **Command Prompt** and run:

```
git clone https://github.com/CodexLabsLLC/Colosseum.git C:\Colosseum
cd C:\Colosseum
build.cmd
```

Wait for build to finish. You will see:

```
Colosseum plugin is built!
```

---

## STEP 4 — Set up the Unreal Project (5 min)

```
mkdir C:\UnrealProjects\PaddyFieldSim\Plugins
xcopy /E /I C:\Colosseum\Unreal\Plugins\AirSim C:\UnrealProjects\PaddyFieldSim\Plugins\AirSim
```

---

## STEP 5 — Create Project in Unreal Engine 5.3 (5 min)

1. Launch UE 5.3 from Epic Games Launcher
2. Select: **Games → Blank → C++ → No Starter Content**
3. Project Location: `C:\UnrealProjects\`
4. Project Name: `PaddyFieldSim`
5. Click **Create**
6. When asked to rebuild modules → click **Yes** (takes 5–10 min)

---

## STEP 6 — Enable AirSim Plugin (2 min)

1. In Unreal Editor → **Edit → Plugins**
2. Search: `AirSim` → tick **Enabled**
3. Restart editor when prompted

---

## STEP 7 — Build the Paddy Field Scene

### A. Set Game Mode

- Window → World Settings → GameMode Override → **AirSimGameMode**

### B. Create Landscape (flat terrain)

- Modes → Landscape → Create New → flat, 256×256 → **Create**
- Apply a brown/green ground material

### C. Add Paddy Plots

- Place → Plane → scale X=5, Y=5
- Apply blue-green water material
- Duplicate 10 times, arrange in rows
- Name them: `PaddyPlot_01` to `PaddyPlot_10`

### D. Add Mud Bunds (boundaries)

- Place → Cube → scale X=5, Y=0.3, Z=0.2
- Place between each paddy row
- Apply brown material

### E. Add Farm Paths

- Place → Plane → scale X=1, Y=20
- Apply dirt/grey material between rows

### F. Add Drone Takeoff Area ⚠️ Important

- Place → Plane → scale X=3, Y=3
- Grey/concrete material
- **Rename it exactly:** `DroneSpawnPoint`
  (Details Panel → top name field → type DroneSpawnPoint)

### G. Add Weed Patches ⚠️ Important

1. Place → Sphere → scale X=0.3, Y=0.3, Z=0.2
2. Apply yellow-green material (RGB: 150, 200, 30)
3. Place 8 weeds scattered inside paddy plots
4. **Name each one:** `WeedPatch_00`, `WeedPatch_01` ... `WeedPatch_07`
5. For each weed → Details Panel → scroll to **Tags** → click **+** → type `WeedPatch`

### H. Add Spray Effect Blueprint ⚠️ Important

1. Content Browser → right-click → Blueprint Class → Actor
2. Name: `BP_SprayEffect`
3. Open it → Add Component → **Niagara Particle System**
4. Set Auto Activate = false
5. Compile and Save
6. Drag 8 copies into the level
7. **Name them:** `BP_SprayEffect_0` to `BP_SprayEffect_7`

### I. Set Lighting

- Click Directional Light → Intensity: 10, Pitch: -45
- Click Sky Light → Intensity: 1.0

---

## STEP 8 — Copy AirSim Settings (1 min)

Copy the `settings.json` file from the zip to:

```
C:\Users\YourName\Documents\AirSim\settings.json
```

Create the `AirSim` folder if it doesn't exist.

---

## STEP 9 — Install Python packages (2 min)

```
pip install airsim opencv-python numpy
```

---

## STEP 10 — Run the Demo

1. In Unreal Editor → click **Play** button
2. Wait for drone to appear in the paddy field
3. Open a new Command Prompt:

```
cd path\to\airsim-paddy\scripts
python demo.py --visualize
```

You should see:

- Drone takes off
- Flies grid pattern over paddy field
- Detects yellow-green weed patches
- Descends and sprays each weed
- Lands
- Saves mission_map.png, weed_report.csv, before/after images

---

## Files saved after demo runs

```
scripts/demo_report/
  mission_map.png        ← top-down map of field + drone path
  weed_report.csv        ← all weed detections with coordinates
  before_after_*.png     ← before/after spray images
  summary.txt            ← mission summary
  detected_*.png         ← annotated detection frames
```

---

## Troubleshooting

| Problem                    | Fix                                                    |
| -------------------------- | ------------------------------------------------------ |
| "AirSimGameMode not found" | Plugin not enabled — check Edit → Plugins → AirSim     |
| Drone doesn't spawn        | Check DroneSpawnPoint actor name is exact              |
| Python can't connect       | Make sure Unreal is in Play mode before running Python |
| Spray not visible          | Check BP_SprayEffect_0..7 are placed in level          |

---
