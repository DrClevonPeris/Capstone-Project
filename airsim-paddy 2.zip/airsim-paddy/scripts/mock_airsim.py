"""
Offline mock for the airsim.MultirotorClient interface.

Why: AirSim only runs when the Unreal paddy field environment is launched
on a Windows/Linux machine. For CI and Mac development we want to be able
to exercise drone_flight.py / weed_detection.py / spray_controller.py
end-to-end without the simulator.

The mock implements only the surface area used by this project. It also
synthesises camera frames containing a few yellow-green "weed" patches so
that detect_weeds() returns non-trivial output.
"""

from __future__ import annotations

import math
import types
from dataclasses import dataclass, field

import numpy as np


# ---------------------------------------------------------------------------
# Lightweight stand-ins for airsim's value types.
# ---------------------------------------------------------------------------


@dataclass
class _Vector3r:
    x_val: float = 0.0
    y_val: float = 0.0
    z_val: float = 0.0


@dataclass
class _Quaternionr:
    w_val: float = 1.0
    x_val: float = 0.0
    y_val: float = 0.0
    z_val: float = 0.0


@dataclass
class _Pose:
    position: _Vector3r = field(default_factory=_Vector3r)
    orientation: _Quaternionr = field(default_factory=_Quaternionr)


class _ImageType:
    Scene = 0
    DepthPlanar = 1
    Segmentation = 5


@dataclass
class _ImageRequest:
    camera_name: str
    image_type: int
    pixels_as_float: bool = False
    compress: bool = True


@dataclass
class _ImageResponse:
    image_data_uint8: bytes
    width: int
    height: int


def _to_quaternion(pitch: float, roll: float, yaw: float) -> _Quaternionr:
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    return _Quaternionr(
        w_val=cr * cp * cy + sr * sp * sy,
        x_val=sr * cp * cy - cr * sp * sy,
        y_val=cr * sp * cy + sr * cp * sy,
        z_val=cr * cp * sy - sr * sp * cy,
    )


# ---------------------------------------------------------------------------
# A tiny "future" object that mirrors the .join() interface from airsim.
# ---------------------------------------------------------------------------


class _ImmediateFuture:
    def __init__(self, result=None):
        self._result = result

    def join(self):
        return self._result


# ---------------------------------------------------------------------------
# Synthetic image generator — produces a brown field with a few yellow-green
# blobs so the colour-based weed detector finds something.
# ---------------------------------------------------------------------------


def _synth_frame(seed: int, width: int = 1280, height: int = 720) -> np.ndarray:
    rng = np.random.default_rng(seed)
    # Brown/green ground (BGR)
    img = np.zeros((height, width, 3), dtype=np.uint8)
    img[:] = (40, 70, 60)  # darkish paddy

    # Occasionally drop in 0–3 weed blobs.
    n_blobs = int(rng.integers(0, 4))
    for _ in range(n_blobs):
        cx = int(rng.integers(80, width - 80))
        cy = int(rng.integers(80, height - 80))
        radius = int(rng.integers(35, 70))
        # Yellow-green BGR ~ (60, 220, 220) — falls in the detector's HSV band.
        yy, xx = np.ogrid[:height, :width]
        mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= radius ** 2
        img[mask] = (60, 220, 220)
    return img


# ---------------------------------------------------------------------------
# The mock client.
# ---------------------------------------------------------------------------


class MockMultirotorClient:
    """Drop-in replacement for airsim.MultirotorClient for offline runs."""

    def __init__(self):
        self._connected = False
        self._api = False
        self._armed = False
        self._pose = _Pose()
        self._waypoint_counter = 0
        self._object_poses: dict[str, _Pose] = {}
        self._object_scales: dict[str, _Vector3r] = {}

    # --- connection lifecycle ---
    def confirmConnection(self):
        self._connected = True

    def enableApiControl(self, on: bool):
        self._api = bool(on)

    def armDisarm(self, on: bool):
        self._armed = bool(on)

    # --- flight commands (all return a joinable future) ---
    def takeoffAsync(self, timeout_sec: float = 10):
        self._pose.position.z_val = -1.5
        return _ImmediateFuture()

    def landAsync(self):
        self._pose.position.z_val = 0.0
        return _ImmediateFuture()

    def moveToZAsync(self, z: float, velocity: float = 2):
        self._pose.position.z_val = float(z)
        return _ImmediateFuture()

    def moveToPositionAsync(self, x: float, y: float, z: float, velocity: float = 3):
        self._pose.position.x_val = float(x)
        self._pose.position.y_val = float(y)
        self._pose.position.z_val = float(z)
        return _ImmediateFuture()

    # --- imaging ---
    def simGetImages(self, requests):
        responses = []
        for _ in requests:
            self._waypoint_counter += 1
            frame = _synth_frame(seed=self._waypoint_counter)
            responses.append(
                _ImageResponse(
                    image_data_uint8=frame.tobytes(),
                    width=frame.shape[1],
                    height=frame.shape[0],
                )
            )
        return responses

    # --- world manipulation (used by spray_controller) ---
    def simSetObjectPose(self, name: str, pose: _Pose, teleport: bool = True):
        self._object_poses[name] = pose
        return True

    def simSetObjectScale(self, name: str, scale: _Vector3r):
        self._object_scales[name] = scale
        return True

    # --- state inspection helpers (handy in tests) ---
    def get_state(self):
        return {
            "connected": self._connected,
            "api": self._api,
            "armed": self._armed,
            "pose": self._pose,
            "object_poses": dict(self._object_poses),
            "object_scales": dict(self._object_scales),
        }


# ---------------------------------------------------------------------------
# install() patches the real `airsim` module so existing scripts pick up the
# mock without code changes. Call this BEFORE importing drone_flight etc.
# ---------------------------------------------------------------------------


def install() -> types.ModuleType:
    """
    Replace `airsim` in sys.modules with a mock-compatible namespace.

    Returns the patched module so callers can poke at it if needed.
    """
    import sys

    fake = types.ModuleType("airsim")
    fake.MultirotorClient = MockMultirotorClient
    fake.Vector3r = _Vector3r
    fake.Quaternionr = _Quaternionr
    fake.Pose = _Pose
    fake.ImageType = _ImageType
    fake.ImageRequest = _ImageRequest
    fake.to_quaternion = _to_quaternion
    sys.modules["airsim"] = fake
    return fake
