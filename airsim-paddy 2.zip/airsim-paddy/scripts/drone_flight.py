"""
Drone flight controller for paddy field weed scanning.
Drone takes off, flies a grid pattern over the field, captures images,
sends them to weed detection, and triggers spray at weed locations.
"""

import airsim
import time
import os
import cv2
import numpy as np
from pathlib import Path
from weed_detection import detect_weeds
from spray_controller import trigger_spray

# --- Configuration ---
FLIGHT_ALTITUDE = -5        # metres (negative = up in AirSim NED frame)
GRID_ROWS = 4               # number of scan rows
GRID_COLS = 6               # waypoints per row
FIELD_WIDTH = 30            # metres
FIELD_LENGTH = 50           # metres
SPEED = 3                   # m/s cruise speed
IMAGE_DIR = Path("captured_images")
IMAGE_DIR.mkdir(exist_ok=True)


def connect_drone():
    client = airsim.MultirotorClient()
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)
    print("[OK] Drone connected and armed.")
    return client


def takeoff(client):
    print("[FLIGHT] Taking off...")
    client.takeoffAsync(timeout_sec=10).join()
    client.moveToZAsync(FLIGHT_ALTITUDE, velocity=2).join()
    time.sleep(1)
    print(f"[FLIGHT] Altitude reached: {FLIGHT_ALTITUDE}m")


def land(client):
    print("[FLIGHT] Landing...")
    client.landAsync().join()
    client.armDisarm(False)
    client.enableApiControl(False)
    print("[FLIGHT] Landed and disarmed.")


def capture_image(client, waypoint_id):
    """Capture bottom-facing camera image and save to disk."""
    responses = client.simGetImages([
        airsim.ImageRequest("bottom_center", airsim.ImageType.Scene, False, False)
    ])
    response = responses[0]
    img_array = np.frombuffer(response.image_data_uint8, dtype=np.uint8)
    img = img_array.reshape(response.height, response.width, 3)
    img_path = IMAGE_DIR / f"waypoint_{waypoint_id:03d}.png"
    cv2.imwrite(str(img_path), img)
    return img, str(img_path)


def generate_grid_waypoints():
    """Generate S-pattern grid waypoints over the paddy field."""
    waypoints = []
    row_spacing = FIELD_LENGTH / GRID_ROWS
    col_spacing = FIELD_WIDTH / GRID_COLS

    for row in range(GRID_ROWS):
        cols = range(GRID_COLS) if row % 2 == 0 else range(GRID_COLS - 1, -1, -1)
        for col in cols:
            x = -FIELD_LENGTH / 2 + row * row_spacing
            y = -FIELD_WIDTH / 2 + col * col_spacing
            waypoints.append((x, y))

    return waypoints


def fly_to(client, x, y, z=FLIGHT_ALTITUDE):
    client.moveToPositionAsync(x, y, z, velocity=SPEED).join()


def run_scan_mission(client):
    """Main scan loop: fly grid, capture images, detect weeds, spray."""
    waypoints = generate_grid_waypoints()
    print(f"[MISSION] Starting scan — {len(waypoints)} waypoints.")
    weed_log = []

    for idx, (x, y) in enumerate(waypoints):
        print(f"[FLIGHT] Waypoint {idx+1}/{len(waypoints)} → ({x:.1f}, {y:.1f})")
        fly_to(client, x, y)
        time.sleep(0.5)

        img, img_path = capture_image(client, idx)
        print(f"[CAMERA] Image saved: {img_path}")

        weeds = detect_weeds(img)

        if weeds:
            print(f"[DETECTION] {len(weeds)} weed(s) found at waypoint {idx}")
            weed_log.append({"waypoint": idx, "position": (x, y), "weeds": weeds})
            trigger_spray(client, x, y, weeds)

    print(f"[MISSION] Scan complete. Weeds found at {len(weed_log)} locations.")
    return weed_log


def main():
    client = connect_drone()
    takeoff(client)

    try:
        weed_log = run_scan_mission(client)
        print("\n[REPORT] Weed locations sprayed:")
        for entry in weed_log:
            print(f"  Waypoint {entry['waypoint']} at {entry['position']}")
    finally:
        land(client)


if __name__ == "__main__":
    main()
