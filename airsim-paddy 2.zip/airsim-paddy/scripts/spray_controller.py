"""
Spray controller — triggers simulated chemical spray in AirSim.
When weeds are detected, drone hovers over the location and activates
the spray particle effect via AirSim simSetObjectPose and custom event.

Improvement #4: Re-spray prevention — tracks already-sprayed world locations
and skips them if the drone passes over the same area again.
"""

import airsim
import time
import math


SPRAY_ALTITUDE = -3.0       # descend to 3m above ground to spray
SPRAY_DURATION = 2.0        # seconds to spray per weed patch
RETURN_ALTITUDE = -5.0      # return to scan altitude after spraying
SPRAY_ACTOR_PREFIX = "BP_SprayEffect"   # Unreal Blueprint actor name prefix
RESPRAY_RADIUS = 2.0        # metres — skip if already sprayed within this distance

# Global set of already-sprayed world coordinates
_sprayed_locations: list[tuple[float, float]] = []


def reset_sprayed_locations():
    """Call at the start of each new mission to clear spray history."""
    _sprayed_locations.clear()


def trigger_spray(client: airsim.MultirotorClient, field_x: float, field_y: float,
                  detections: list[dict]):
    """
    Hover over each detected weed and activate spray effect.

    Args:
        client: Connected AirSim drone client
        field_x, field_y: Current drone ground position
        detections: Weed detection results from weed_detection.py
    """
    print(f"[SPRAY] {len(detections)} weed(s) detected — initiating spray sequence.")
    sprayed_count = 0
    skipped_count = 0

    for i, det in enumerate(detections):
        spray_x, spray_y = _pixel_to_world(det["center"], field_x, field_y)

        # Improvement #4 — skip if already sprayed nearby
        if _already_sprayed(spray_x, spray_y):
            print(f"[SPRAY] Weed {i+1} at ({spray_x:.1f}, {spray_y:.1f}) "
                  f"already sprayed — skipping.")
            skipped_count += 1
            continue

        print(f"[SPRAY] Moving to weed {i+1} at world ({spray_x:.1f}, {spray_y:.1f})")

        # Descend to spray altitude
        client.moveToPositionAsync(spray_x, spray_y, SPRAY_ALTITUDE, velocity=2).join()
        time.sleep(0.5)

        # Activate spray Blueprint actor in Unreal via simSetObjectPose
        _activate_spray_actor(client, spray_x, spray_y, i)

        print(f"[SPRAY] Spraying for {SPRAY_DURATION}s...")
        time.sleep(SPRAY_DURATION)

        # Deactivate spray
        _deactivate_spray_actor(client, i)

        # Record this location as sprayed
        _sprayed_locations.append((spray_x, spray_y))
        sprayed_count += 1

        # Return to scan altitude
        client.moveToZAsync(RETURN_ALTITUDE, velocity=2).join()

    print(f"[SPRAY] Sequence complete — sprayed: {sprayed_count}, skipped: {skipped_count}.")


def _activate_spray_actor(client: airsim.MultirotorClient, x: float, y: float, idx: int):
    """Move the spray Blueprint actor to the weed location and enable it."""
    actor_name = f"{SPRAY_ACTOR_PREFIX}_{idx}"
    pose = airsim.Pose(
        airsim.Vector3r(x, y, -0.5),     # place just above ground
        airsim.to_quaternion(0, 0, 0)
    )
    try:
        client.simSetObjectPose(actor_name, pose, teleport=True)
        # Custom event to enable particle system (set via Unreal Blueprint)
        client.simSetObjectScale(actor_name, airsim.Vector3r(1, 1, 1))
        print(f"[SPRAY] Actor '{actor_name}' activated.")
    except Exception as e:
        print(f"[SPRAY] Warning: Could not activate actor '{actor_name}': {e}")
        print("[SPRAY] Ensure BP_SprayEffect actors are placed in the Unreal level.")


def _deactivate_spray_actor(client: airsim.MultirotorClient, idx: int):
    """Hide the spray actor after spraying."""
    actor_name = f"{SPRAY_ACTOR_PREFIX}_{idx}"
    try:
        client.simSetObjectScale(actor_name, airsim.Vector3r(0, 0, 0))
    except Exception:
        pass


def _already_sprayed(x: float, y: float) -> bool:
    """Return True if a location within RESPRAY_RADIUS has already been sprayed."""
    for sx, sy in _sprayed_locations:
        dist = math.sqrt((x - sx) ** 2 + (y - sy) ** 2)
        if dist < RESPRAY_RADIUS:
            return True
    return False


def _pixel_to_world(pixel_center: tuple, drone_x: float, drone_y: float,
                    image_width: int = 1280, image_height: int = 720,
                    fov_metres: float = 10.0) -> tuple:
    """
    Convert pixel detection center to approximate world coordinates.
    Assumes nadir (downward) camera at known drone position.
    fov_metres: approximate ground coverage width at current altitude.
    """
    px, py = pixel_center
    offset_x = ((py / image_height) - 0.5) * fov_metres
    offset_y = ((px / image_width) - 0.5) * fov_metres
    world_x = drone_x + offset_x
    world_y = drone_y + offset_y
    return world_x, world_y
