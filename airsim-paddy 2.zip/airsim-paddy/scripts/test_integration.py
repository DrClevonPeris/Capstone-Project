"""
Integration smoke test — runs the full pipeline against the offline mock.

This does NOT require Unreal, AirSim, or a network connection. It exists so
CI and `pytest`-style local runs can guarantee that drone_flight,
weed_detection, and spray_controller still wire together correctly.

Run:
    python test_integration.py
or
    pytest test_integration.py
"""

from __future__ import annotations

import sys
from pathlib import Path

# IMPORTANT: install the mock BEFORE importing anything that touches airsim.
import mock_airsim
mock_airsim.install()

# Crank down sleeps so the test runs in seconds, not minutes.
import spray_controller  # noqa: E402
spray_controller.SPRAY_DURATION = 0.0
spray_controller.time.sleep = lambda *_a, **_k: None  # no-op spray waits

from integration import MissionReport, pixel_to_world, run_mission  # noqa: E402


def _run() -> MissionReport:
    client = mock_airsim.MockMultirotorClient()
    report = run_mission(
        client=client,
        dry_run=False,
        visualize=False,
        report_dir=Path("demo_report"),
    )
    return report


def test_run_mission_visits_all_waypoints():
    report = _run()
    # generate_grid_waypoints() yields GRID_ROWS * GRID_COLS = 4 * 6 = 24.
    assert len(report.waypoints) == 24, (
        f"expected 24 waypoints, got {len(report.waypoints)}"
    )


def test_run_mission_finds_some_weeds():
    report = _run()
    # The synthetic frames are randomized but seeded; with 24 frames we
    # should reliably see at least one weed somewhere.
    assert report.total_weeds > 0, "mock should produce at least one weed"


def test_run_mission_sprays_when_weeds_detected():
    report = _run()
    sprayed = [w for w in report.waypoints if w.sprayed]
    detected = [w for w in report.waypoints if w.detections]
    assert sprayed == detected, (
        "every waypoint with detections should also have been sprayed"
    )


def test_pixel_to_world_centre_is_drone_position():
    # Pixel at the exact image centre should map to (drone_x, drone_y).
    wx, wy = pixel_to_world((640, 360), drone_x=10.0, drone_y=-5.0)
    assert abs(wx - 10.0) < 1e-6
    assert abs(wy - (-5.0)) < 1e-6


def test_pixel_to_world_offsets_have_expected_sign():
    # A pixel to the right (px > centre_x) should produce a +y world offset
    # given the camera convention used in spray_controller._pixel_to_world.
    wx, wy = pixel_to_world((900, 360), drone_x=0.0, drone_y=0.0)
    assert wy > 0, f"right-of-centre pixel should yield +y, got {wy}"
    assert abs(wx) < 1e-6, f"vertically-centred pixel should give wx≈0, got {wx}"


# ---------------------------------------------------------------------------
# Allow `python test_integration.py` to behave like a tiny test runner so we
# don't force pytest as a dependency.
# ---------------------------------------------------------------------------


def _run_all():
    tests = [
        test_run_mission_visits_all_waypoints,
        test_run_mission_finds_some_weeds,
        test_run_mission_sprays_when_weeds_detected,
        test_pixel_to_world_centre_is_drone_position,
        test_pixel_to_world_offsets_have_expected_sign,
    ]
    failures = 0
    for fn in tests:
        try:
            fn()
            print(f"  [PASS] {fn.__name__}")
        except AssertionError as exc:
            failures += 1
            print(f"  [FAIL] {fn.__name__}: {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"  [ERROR] {fn.__name__}: {type(exc).__name__}: {exc}")
    print()
    print(f"  {len(tests) - failures}/{len(tests)} tests passed.")
    return failures


if __name__ == "__main__":
    print("=" * 60)
    print("  AirSim Paddy Field — Integration Smoke Test")
    print("=" * 60)
    sys.exit(0 if _run_all() == 0 else 1)
