"""
Integration bridge between drone flight, weed detection, and spray control.

This module exposes a single high-level entry point — `run_mission()` — that
wires the three subsystems together with a clean, testable interface.

The bridge is what lets us swap the real AirSim client for the mock in
mock_airsim.py: every subsystem only ever talks to the `client` object that
this module hands it.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import cv2
import numpy as np

from drone_flight import (
    FLIGHT_ALTITUDE,
    capture_image,
    connect_drone,
    fly_to,
    generate_grid_waypoints,
    land,
    takeoff,
)
from spray_controller import trigger_spray, reset_sprayed_locations
from weed_detection import detect_weeds, draw_detections
from mission_map import generate_mission_map
from report_generator import save_csv_report, save_before_after, save_summary_txt


# ---------------------------------------------------------------------------
# Result types — small dataclasses so callers don't depend on dict layout.
# ---------------------------------------------------------------------------


@dataclass
class WaypointResult:
    waypoint_id: int
    position: tuple[float, float]
    image_path: str
    detections: list[dict] = field(default_factory=list)
    sprayed: bool = False


@dataclass
class MissionReport:
    waypoints: list[WaypointResult] = field(default_factory=list)

    @property
    def total_weeds(self) -> int:
        return sum(len(w.detections) for w in self.waypoints)

    @property
    def sprayed_locations(self) -> list[tuple[float, float]]:
        return [w.position for w in self.waypoints if w.sprayed]

    def summary(self) -> str:
        return (
            f"Waypoints visited : {len(self.waypoints)}\n"
            f"Total weeds       : {self.total_weeds}\n"
            f"Sprayed locations : {len(self.sprayed_locations)}"
        )


# ---------------------------------------------------------------------------
# Mission runner.
# ---------------------------------------------------------------------------


def run_mission(
    *,
    client=None,
    dry_run: bool = False,
    visualize: bool = False,
    on_waypoint: Optional[Callable[[WaypointResult], None]] = None,
    report_dir: Path | str = "demo_report",
) -> MissionReport:
    """
    Fly the grid, detect weeds at each waypoint, and (unless dry_run) spray.

    Args:
        client: An object implementing the airsim.MultirotorClient surface.
                If None, the real airsim client is used via connect_drone().
        dry_run: Skip spray actions.
        visualize: Show an OpenCV window with annotated detections.
        on_waypoint: Optional callback invoked after each waypoint.
        report_dir: Where annotated detection images are saved.

    Returns:
        MissionReport with per-waypoint results.
    """
    report_dir = Path(report_dir)
    report_dir.mkdir(exist_ok=True)

    # Reset spray history for fresh mission
    reset_sprayed_locations()

    if client is None:
        client = connect_drone()
    else:
        client.confirmConnection()
        client.enableApiControl(True)
        client.armDisarm(True)

    takeoff(client)

    report = MissionReport()
    waypoints = generate_grid_waypoints()

    # Improvement #5 — before/after image stores
    before_images: dict[int, np.ndarray] = {}
    after_images: dict[int, np.ndarray] = {}

    try:
        for idx, (x, y) in enumerate(waypoints):
            fly_to(client, x, y)
            time.sleep(0.05)

            img, img_path = capture_image(client, idx)
            detections = detect_weeds(img)

            wp = WaypointResult(
                waypoint_id=idx,
                position=(x, y),
                image_path=img_path,
                detections=detections,
            )

            if detections:
                # Save before image
                before_images[idx] = img.copy()

                annotated = draw_detections(img, detections)
                out = report_dir / f"detected_{idx:03d}.png"
                cv2.imwrite(str(out), annotated)

                if visualize:
                    cv2.imshow("Weed Detection", annotated)
                    cv2.waitKey(200)

                if not dry_run:
                    trigger_spray(client, x, y, detections)
                    wp.sprayed = True

                    # Capture after image post-spray
                    after_img, _ = capture_image(client, idx * 1000)
                    after_images[idx] = after_img

            report.waypoints.append(wp)
            if on_waypoint:
                on_waypoint(wp)

    finally:
        land(client)
        if visualize:
            cv2.destroyAllWindows()

    # --- Generate all reports ---
    generate_mission_map(report.waypoints, report_dir / "mission_map.png")
    save_csv_report(report.waypoints, report_dir / "weed_report.csv")
    save_before_after(report.waypoints, before_images, after_images, report_dir)
    save_summary_txt(report.waypoints, report_dir / "summary.txt")

    return report


# ---------------------------------------------------------------------------
# Coordinate helpers — re-exported here so other modules have a single
# import surface.
# ---------------------------------------------------------------------------


def pixel_to_world(
    pixel_center: tuple[int, int],
    drone_x: float,
    drone_y: float,
    *,
    image_width: int = 1280,
    image_height: int = 720,
    fov_metres: float = 10.0,
) -> tuple[float, float]:
    """Mirror of spray_controller._pixel_to_world, exposed for callers/tests."""
    px, py = pixel_center
    offset_x = ((py / image_height) - 0.5) * fov_metres
    offset_y = ((px / image_width) - 0.5) * fov_metres
    return drone_x + offset_x, drone_y + offset_y


__all__ = [
    "WaypointResult",
    "MissionReport",
    "run_mission",
    "pixel_to_world",
]
