"""
Weed detection module — Environment Integration layer.
Receives a camera image from the drone and returns weed pixel locations.

Improvement #3: Added confidence threshold, minimum size filter,
aspect-ratio filter, and NMS (non-maximum suppression) to reduce
false positives and duplicate detections.

NOTE: Replace _color_based_stub() with your team's trained model when ready.
The interface is fixed: input = numpy image, output = list of detection dicts.
"""

import cv2
import numpy as np


# --- Detection thresholds (tune these for your environment) ---
MIN_AREA = 800            # px² — ignore tiny noise blobs
MAX_AREA = 80_000         # px² — ignore huge false-positive regions
MIN_CONFIDENCE = 0.25     # 0–1  — drop low-confidence detections
MAX_ASPECT_RATIO = 5.0    # w/h or h/w — ignore very thin lines
NMS_OVERLAP_THRESH = 0.3  # IoU threshold for duplicate suppression


def detect_weeds(image: np.ndarray) -> list[dict]:
    """
    Detect weeds in a drone camera image.

    Args:
        image: BGR numpy array (H x W x 3)

    Returns:
        List of dicts: [{"bbox": (x, y, w, h), "confidence": float, "center": (cx, cy)}]
        Filtered by confidence threshold, size, aspect ratio, and NMS.
    """
    raw = _color_based_stub(image)
    filtered = _apply_filters(raw)
    return filtered


def _color_based_stub(image: np.ndarray) -> list[dict]:
    """
    Detector using HSV color filtering.
    Detects yellow-green patches (weed color) distinct from healthy dark-green paddy.
    Replace this function body with your model's inference when ready.
    """
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Primary weed range: yellowish-green, S>140 excludes dim background colours
    lower_weed = np.array([22, 140, 80])
    upper_weed = np.array([45, 255, 255])
    mask1 = cv2.inRange(hsv, lower_weed, upper_weed)

    # Secondary range: bright yellow (drought-stressed weeds)
    lower_yellow = np.array([18, 140, 100])
    upper_yellow = np.array([28, 255, 255])
    mask2 = cv2.inRange(hsv, lower_yellow, upper_yellow)

    mask = cv2.bitwise_or(mask1, mask2)

    # Morphological cleanup — remove noise, fill gaps
    kernel = np.ones((7, 7), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_DILATE, np.ones((3, 3), np.uint8))

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    detections = []
    for contour in contours:
        area = cv2.contourArea(contour)
        x, y, w, h = cv2.boundingRect(contour)
        cx, cy = x + w // 2, y + h // 2
        confidence = min(area / 6000.0, 1.0)
        detections.append({
            "bbox": (x, y, w, h),
            "confidence": round(confidence, 2),
            "center": (cx, cy),
            "area": area,
        })

    return detections


def _apply_filters(detections: list[dict]) -> list[dict]:
    """
    Improvement #3 — Filter raw detections:
    1. Remove detections outside area bounds
    2. Remove low-confidence detections
    3. Remove detections with extreme aspect ratios (false lines/edges)
    4. Apply NMS to remove duplicate overlapping boxes
    """
    filtered = []
    for det in detections:
        area = det.get("area", 0)
        if area < MIN_AREA or area > MAX_AREA:
            continue
        if det["confidence"] < MIN_CONFIDENCE:
            continue
        _, _, w, h = det["bbox"]
        ratio = max(w, h) / max(min(w, h), 1)
        if ratio > MAX_ASPECT_RATIO:
            continue
        filtered.append(det)

    # Non-Maximum Suppression — remove overlapping duplicates
    filtered = _nms(filtered, NMS_OVERLAP_THRESH)
    return filtered


def _nms(detections: list[dict], iou_threshold: float) -> list[dict]:
    """Remove overlapping detections — keep the highest confidence one."""
    if len(detections) <= 1:
        return detections

    detections = sorted(detections, key=lambda d: d["confidence"], reverse=True)
    kept = []
    while detections:
        best = detections.pop(0)
        kept.append(best)
        detections = [
            d for d in detections
            if _iou(best["bbox"], d["bbox"]) < iou_threshold
        ]
    return kept


def _iou(box_a: tuple, box_b: tuple) -> float:
    """Compute Intersection over Union of two (x,y,w,h) boxes."""
    ax, ay, aw, ah = box_a
    bx, by, bw, bh = box_b
    ix = max(ax, bx)
    iy = max(ay, by)
    iw = max(0, min(ax + aw, bx + bw) - ix)
    ih = max(0, min(ay + ah, by + bh) - iy)
    intersection = iw * ih
    union = aw * ah + bw * bh - intersection
    return intersection / union if union > 0 else 0.0


def draw_detections(image: np.ndarray, detections: list[dict]) -> np.ndarray:
    """Draw bounding boxes on image for visualization."""
    annotated = image.copy()
    for det in detections:
        x, y, w, h = det["bbox"]
        conf = det["confidence"]
        # Colour by confidence: green = high, orange = medium, red = low
        if conf >= 0.7:
            colour = (0, 200, 0)
        elif conf >= 0.4:
            colour = (0, 165, 255)
        else:
            colour = (0, 0, 220)
        cv2.rectangle(annotated, (x, y), (x + w, y + h), colour, 2)
        label = f"Weed {conf:.0%}"
        cv2.putText(annotated, label, (x, max(y - 6, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1)
    return annotated
