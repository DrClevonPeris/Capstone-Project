"""
Mission Map Generator — Improvement #1
Generates a 2D top-down visual map of the paddy field showing:
  - Drone flight path (blue line)
  - Waypoints visited (grey dots)
  - Weed detections (red markers)
  - Sprayed locations (green markers)
  - Field boundary (green border)
Saves the map as mission_map.png in the report directory.
"""

from __future__ import annotations

import cv2
import numpy as np
from pathlib import Path
from drone_flight import FIELD_WIDTH, FIELD_LENGTH


# Map canvas size in pixels
MAP_W = 800
MAP_H = 600
PADDING = 60   # pixels of padding around the field


def _world_to_pixel(x: float, y: float) -> tuple[int, int]:
    """Convert AirSim world coords (metres) to map pixel coords."""
    px = int(PADDING + (y + FIELD_WIDTH / 2) / FIELD_WIDTH * (MAP_W - 2 * PADDING))
    py = int(PADDING + (x + FIELD_LENGTH / 2) / FIELD_LENGTH * (MAP_H - 2 * PADDING))
    return px, py


def generate_mission_map(
    waypoints: list,           # list of WaypointResult from integration.py
    save_path: str | Path = "demo_report/mission_map.png",
) -> np.ndarray:
    """
    Generate and save the mission map.

    Args:
        waypoints: List of WaypointResult objects from the mission report.
        save_path: Where to save the PNG.

    Returns:
        The map as a BGR numpy array.
    """
    # Background — dark green paddy field
    canvas = np.zeros((MAP_H, MAP_W, 3), dtype=np.uint8)
    canvas[:] = (30, 60, 30)

    # Field boundary
    tl = _world_to_pixel(-FIELD_LENGTH / 2, -FIELD_WIDTH / 2)
    br = _world_to_pixel(FIELD_LENGTH / 2, FIELD_WIDTH / 2)
    cv2.rectangle(canvas, tl, br, (0, 180, 0), 2)

    # Paddy plot grid lines (visual only)
    rows, cols = 4, 6
    for r in range(1, rows):
        x = -FIELD_LENGTH / 2 + r * FIELD_LENGTH / rows
        p1 = _world_to_pixel(x, -FIELD_WIDTH / 2)
        p2 = _world_to_pixel(x, FIELD_WIDTH / 2)
        cv2.line(canvas, p1, p2, (0, 100, 0), 1)
    for c in range(1, cols):
        y = -FIELD_WIDTH / 2 + c * FIELD_WIDTH / cols
        p1 = _world_to_pixel(-FIELD_LENGTH / 2, y)
        p2 = _world_to_pixel(FIELD_LENGTH / 2, y)
        cv2.line(canvas, p1, p2, (0, 100, 0), 1)

    # Flight path (blue line connecting waypoints in order)
    positions = [wp.position for wp in waypoints]
    for i in range(1, len(positions)):
        p1 = _world_to_pixel(*positions[i - 1])
        p2 = _world_to_pixel(*positions[i])
        cv2.line(canvas, p1, p2, (200, 120, 0), 1)

    # Waypoint dots
    for wp in waypoints:
        px = _world_to_pixel(*wp.position)
        cv2.circle(canvas, px, 3, (160, 160, 160), -1)

    # Weed detections (red circles)
    for wp in waypoints:
        if wp.detections:
            px = _world_to_pixel(*wp.position)
            cv2.circle(canvas, px, 10, (0, 0, 220), 2)
            cv2.putText(canvas, str(len(wp.detections)),
                        (px[0] + 6, px[1] - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 220), 1)

    # Sprayed locations (filled green circle over red)
    for wp in waypoints:
        if wp.sprayed:
            px = _world_to_pixel(*wp.position)
            cv2.circle(canvas, px, 8, (0, 220, 80), -1)
            cv2.circle(canvas, px, 10, (0, 255, 100), 1)

    # Drone start marker
    if positions:
        start = _world_to_pixel(*positions[0])
        cv2.circle(canvas, start, 7, (255, 200, 0), -1)
        cv2.putText(canvas, "START", (start[0] + 8, start[1] + 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 200, 0), 1)

    # Legend
    _draw_legend(canvas)

    # Title
    cv2.putText(canvas, "Paddy Field Mission Map",
                (PADDING, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (220, 220, 220), 1)

    # Stats bar
    total_weeds = sum(len(wp.detections) for wp in waypoints)
    sprayed = sum(1 for wp in waypoints if wp.sprayed)
    stats = f"Waypoints: {len(waypoints)}   Weeds: {total_weeds}   Sprayed: {sprayed}"
    cv2.putText(canvas, stats, (PADDING, MAP_H - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)

    Path(save_path).parent.mkdir(exist_ok=True)
    cv2.imwrite(str(save_path), canvas)
    print(f"[MAP] Mission map saved: {save_path}")
    return canvas


def _draw_legend(canvas: np.ndarray):
    x, y = MAP_W - 155, PADDING
    items = [
        ((200, 120, 0), "─", "Flight path"),
        ((160, 160, 160), "●", "Waypoint"),
        ((0, 0, 220), "○", "Weed detected"),
        ((0, 220, 80), "●", "Sprayed"),
        ((255, 200, 0), "●", "Start"),
    ]
    cv2.rectangle(canvas, (x - 8, y - 18), (MAP_W - 8, y + len(items) * 18 + 4),
                  (50, 50, 50), -1)
    cv2.rectangle(canvas, (x - 8, y - 18), (MAP_W - 8, y + len(items) * 18 + 4),
                  (100, 100, 100), 1)
    for colour, sym, label in items:
        cv2.circle(canvas, (x + 6, y - 2), 5, colour, -1)
        cv2.putText(canvas, label, (x + 16, y + 3),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (210, 210, 210), 1)
        y += 18
