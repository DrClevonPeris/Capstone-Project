"""
Final demo script — runs the complete weed detection and spray workflow.
Run this after launching the Unreal paddy field environment.

Usage:
    python demo.py
    python demo.py --visualize      # show live detection feed
    python demo.py --dry-run        # fly and capture only, no spray
    python demo.py --mock           # use mock AirSim client (no Unreal needed)
"""

import argparse


def run_demo(visualize: bool = False, dry_run: bool = False, mock: bool = False):
    print("=" * 60)
    print("  AirSim Paddy Field — Weed Detection & Spray Demo")
    print("=" * 60)

    client = None
    if mock:
        # Patch `airsim` in sys.modules BEFORE importing the rest of the stack,
        # otherwise drone_flight / spray_controller will pull in the real
        # airsim package.
        import mock_airsim
        mock_airsim.install()
        client = mock_airsim.MockMultirotorClient()
        print("[DEMO] Running with mock AirSim client (no Unreal required).")

    from integration import run_mission

    report = run_mission(
        client=client,
        dry_run=dry_run,
        visualize=visualize,
    )

    print("\n" + "=" * 60)
    print("  DEMO COMPLETE")
    print(report.summary())
    print("=" * 60)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--visualize", action="store_true",
                        help="Show live detection window")
    parser.add_argument("--dry-run", action="store_true",
                        help="Capture and detect only, skip spray")
    parser.add_argument("--mock", action="store_true",
                        help="Use the offline mock AirSim client (no Unreal)")
    args = parser.parse_args()
    run_demo(visualize=args.visualize, dry_run=args.dry_run, mock=args.mock)
