"""
Report Generator — Improvements #2 and #5
Generates:
  - CSV report with weed locations, confidence, timestamps, spray status
  - Before/after screenshot pairs for each sprayed weed location
  - Summary text report
"""

from __future__ import annotations

import csv
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path


def save_csv_report(
    waypoints: list,
    save_path: str | Path = "demo_report/weed_report.csv",
) -> Path:
    """
    Save per-detection CSV report.

    Columns: waypoint_id, world_x, world_y, weed_id,
             bbox_x, bbox_y, bbox_w, bbox_h, confidence, sprayed, timestamp
    """
    save_path = Path(save_path)
    save_path.parent.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(save_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "waypoint_id", "world_x", "world_y",
            "weed_id", "bbox_x", "bbox_y", "bbox_w", "bbox_h",
            "confidence", "sprayed", "timestamp"
        ])
        for wp in waypoints:
            for weed_id, det in enumerate(wp.detections):
                bx, by, bw, bh = det["bbox"]
                writer.writerow([
                    wp.waypoint_id,
                    round(wp.position[0], 2),
                    round(wp.position[1], 2),
                    weed_id,
                    bx, by, bw, bh,
                    det["confidence"],
                    wp.sprayed,
                    timestamp,
                ])

    total_weeds = sum(len(wp.detections) for wp in waypoints)
    print(f"[REPORT] CSV saved: {save_path} ({total_weeds} detections)")
    return save_path


def save_before_after(
    waypoints: list,
    before_images: dict[int, np.ndarray],
    after_images: dict[int, np.ndarray],
    report_dir: str | Path = "demo_report",
) -> list[Path]:
    """
    Save side-by-side before/after images for each sprayed waypoint.

    Args:
        waypoints: List of WaypointResult.
        before_images: Dict of waypoint_id → BGR image captured before spray.
        after_images:  Dict of waypoint_id → BGR image captured after spray.
        report_dir: Output directory.

    Returns:
        List of saved file paths.
    """
    report_dir = Path(report_dir)
    report_dir.mkdir(exist_ok=True)
    saved = []

    for wp in waypoints:
        if not wp.sprayed:
            continue
        wid = wp.waypoint_id
        before = before_images.get(wid)
        after = after_images.get(wid)
        if before is None or after is None:
            continue

        # Resize both to same height
        h = min(before.shape[0], after.shape[0])
        w = min(before.shape[1], after.shape[1])
        before_r = cv2.resize(before, (w, h))
        after_r = cv2.resize(after, (w, h))

        # Add labels
        _label(before_r, "BEFORE SPRAY", (0, 80, 200))
        _label(after_r, "AFTER SPRAY", (0, 180, 60))

        # Draw detections on before image
        from weed_detection import draw_detections
        before_r = draw_detections(before_r, wp.detections)

        # Mark sprayed area on after image (green overlay)
        for det in wp.detections:
            x, y, bw, bh = det["bbox"]
            overlay = after_r.copy()
            cv2.rectangle(overlay, (x, y), (x + bw, y + bh), (0, 200, 60), -1)
            cv2.addWeighted(overlay, 0.25, after_r, 0.75, 0, after_r)
            cv2.rectangle(after_r, (x, y), (x + bw, y + bh), (0, 255, 80), 2)
            cv2.putText(after_r, "SPRAYED", (x, y - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 80), 1)

        # Divider line
        divider = np.full((h, 4, 3), 200, dtype=np.uint8)
        combined = np.hstack([before_r, divider, after_r])

        out = report_dir / f"before_after_{wid:03d}.png"
        cv2.imwrite(str(out), combined)
        saved.append(out)

    print(f"[REPORT] {len(saved)} before/after image(s) saved to {report_dir}/")
    return saved


def save_summary_txt(
    waypoints: list,
    save_path: str | Path = "demo_report/summary.txt",
) -> Path:
    """Save a plain-text mission summary for the project report."""
    save_path = Path(save_path)
    save_path.parent.mkdir(exist_ok=True)

    total_weeds = sum(len(wp.detections) for wp in waypoints)
    sprayed = [wp for wp in waypoints if wp.sprayed]
    avg_conf = 0.0
    all_confs = [d["confidence"] for wp in waypoints for d in wp.detections]
    if all_confs:
        avg_conf = sum(all_confs) / len(all_confs)

    lines = [
        "=" * 55,
        "  AirSim Paddy Field — Mission Summary Report",
        "=" * 55,
        f"  Date/Time      : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"  Waypoints      : {len(waypoints)}",
        f"  Weeds detected : {total_weeds}",
        f"  Locations sprayed: {len(sprayed)}",
        f"  Avg confidence : {avg_conf:.1%}",
        "",
        "  Sprayed Locations:",
    ]
    for wp in sprayed:
        lines.append(
            f"    Waypoint {wp.waypoint_id:02d} → "
            f"({wp.position[0]:.1f}m, {wp.position[1]:.1f}m) "
            f"— {len(wp.detections)} weed(s)"
        )
    lines += ["", "=" * 55]

    save_path.write_text("\n".join(lines))
    print(f"[REPORT] Summary saved: {save_path}")
    return save_path


def _label(img: np.ndarray, text: str, colour: tuple):
    """Draw a label bar at the top of an image in-place."""
    cv2.rectangle(img, (0, 0), (img.shape[1], 28), (20, 20, 20), -1)
    cv2.putText(img, text, (10, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, colour, 2)
