# AirSim Paddy Field — Weed Detection & Spray Demo

A student project that flies a simulated drone in an Unreal/AirSim paddy
field, scans each plot with a downward camera, detects weed patches by
colour, and triggers a particle spray over each detection.

```
┌────────────┐   images   ┌─────────────────┐   bboxes   ┌────────────────┐
│ drone_     │ ─────────▶ │ weed_detection  │ ─────────▶ │ spray_         │
│ flight.py  │            │      .py        │            │ controller.py  │
└────────────┘            └─────────────────┘            └────────────────┘
       ▲                                                          │
       │                  integration.run_mission()               │
       └──────────────────────────────────────────────────────────┘
```

## Repo layout

```
airsim-paddy/
├── README.md                  ← you are here
├── blueprints/
│   └── BP_SprayEffect.md      ← spec for the Unreal Blueprint
├── config/
│   └── settings.json          ← AirSim drone + camera config
├── docs/
│   ├── mac_setup_guide.md     ← Mac dev workflow
│   └── unreal_setup_steps.md  ← Windows / Unreal scene workflow
└── scripts/
    ├── requirements.txt
    ├── drone_flight.py        ← grid waypoints, takeoff/land, capture
    ├── weed_detection.py      ← HSV stub detector (swap with your model)
    ├── spray_controller.py    ← moves & toggles BP_SprayEffect actors
    ├── integration.py         ← run_mission() bridge + MissionReport
    ├── mock_airsim.py         ← offline AirSim client + synthetic frames
    ├── demo.py                ← CLI entry point
    └── test_integration.py    ← smoke test against the mock
```

## Quick start

### 1. Install Python deps

```bash
cd scripts
pip install -r requirements.txt
```

### 2. Run the offline smoke test (no Unreal required)

```bash
python test_integration.py
```

This patches `airsim` with the mock client, flies the full grid against
synthetic frames, and verifies every waypoint, every detection, and every
spray firing. Use this anywhere — Mac, CI, plane wifi.

### 3. Run the demo against the mock

```bash
python demo.py --mock --visualize
```

### 4. Run the demo against a real Unreal scene

1. Build the paddy field environment using
   [`docs/unreal_setup_steps.md`](docs/unreal_setup_steps.md) (Windows) or
   [`docs/mac_setup_guide.md`](docs/mac_setup_guide.md) (Mac).
2. Place `BP_SprayEffect_0` … `BP_SprayEffect_7` as described in
   [`blueprints/BP_SprayEffect.md`](blueprints/BP_SprayEffect.md).
3. Copy `config/settings.json` to your AirSim settings location:
   - **Windows:** `C:\Users\<you>\Documents\AirSim\settings.json`
   - **macOS / Linux:** `~/Documents/AirSim/settings.json`
4. Press **Play** in the Unreal editor.
5. From `scripts/`:
   ```bash
   python demo.py --visualize
   ```

## CLI flags

| Flag           | Purpose                                              |
|----------------|------------------------------------------------------|
| `--visualize`  | Pop up an OpenCV window showing each annotated frame |
| `--dry-run`    | Fly + detect, but skip spray actions                 |
| `--mock`       | Use the offline mock AirSim client (no Unreal)       |

Flags compose, e.g. `python demo.py --mock --dry-run`.

## How the integration is wired

`integration.run_mission()` is the single entry point that orchestrates the
three subsystems. It accepts an optional `client=` argument: pass a real
`airsim.MultirotorClient` for the live demo, or a `MockMultirotorClient`
from `mock_airsim.py` for offline runs. Everything downstream
(`drone_flight`, `spray_controller`) talks only to that injected client, so
swapping in the mock requires no code changes elsewhere.

`MissionReport` is the structured return type — a list of `WaypointResult`
records plus convenience properties (`total_weeds`, `sprayed_locations`).

## Replacing the stub detector

`weed_detection.detect_weeds(image)` currently uses an HSV colour filter.
The interface is fixed:

```python
def detect_weeds(image: np.ndarray) -> list[dict]:
    # returns: [{"bbox": (x, y, w, h), "confidence": float, "center": (cx, cy)}, ...]
```

Drop your trained model behind that signature and the rest of the pipeline
keeps working unchanged. The smoke test will continue to verify wiring even
after the swap.
