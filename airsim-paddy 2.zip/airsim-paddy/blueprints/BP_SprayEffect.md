# BP_SprayEffect — Blueprint Specification

This document specifies the `BP_SprayEffect` Actor Blueprint that is referenced
by `scripts/spray_controller.py`. Recreate it inside the Unreal project at
`PaddyFieldSim/Content/Blueprints/BP_SprayEffect`.

> Unreal Blueprints are binary `.uasset` files and cannot be checked into a
> plain Git repo as text. Use this spec to rebuild the blueprint in-editor.

---

## Class

- **Parent class:** `Actor`
- **Path in project:** `/Game/Blueprints/BP_SprayEffect`
- **Asset name:** `BP_SprayEffect`

## Components

| Component | Type | Notes |
|-----------|------|-------|
| `DefaultSceneRoot` | SceneComponent | Root |
| `SprayParticles` | ParticleSystemComponent | `Auto Activate = false`, template `P_Water_Splash` (or any spray particle) |
| `SprayAudio` *(optional)* | AudioComponent | `Auto Activate = false`, hiss/spray cue |

## Variables

| Name | Type | Default | Tooltip |
|------|------|---------|---------|
| `IsSpraying` | bool | false | Read-only state flag |
| `SprayLifetime` | float | 2.0 | Auto-deactivate timer |

## Event Graph

```
Event BeginPlay
  └─> Set Visibility (SprayParticles, false)
  └─> Set IsSpraying = false

Custom Event: Activate
  ├─> Set Visibility (SprayParticles, true)
  ├─> Activate (SprayParticles)
  ├─> Activate (SprayAudio)            # if present
  ├─> Set IsSpraying = true
  └─> Delay (SprayLifetime) -> Deactivate

Custom Event: Deactivate
  ├─> Deactivate (SprayParticles)
  ├─> Set Visibility (SprayParticles, false)
  └─> Set IsSpraying = false
```

## Level Placement

Place 8 instances in the level and rename them exactly:

```
BP_SprayEffect_0
BP_SprayEffect_1
BP_SprayEffect_2
BP_SprayEffect_3
BP_SprayEffect_4
BP_SprayEffect_5
BP_SprayEffect_6
BP_SprayEffect_7
```

The Python `spray_controller.py` resolves them by exact name via
`simSetObjectPose`. Position in the editor doesn't matter — they get
teleported at runtime.

## Why scale-to-zero instead of a custom event?

`spray_controller.py` activates and deactivates each spray actor by setting
its scale to `(1,1,1)` or `(0,0,0)` because that round-trip is exposed by the
stock AirSim Python API (`simSetObjectScale`). If the team prefers to drive
the `Activate`/`Deactivate` Custom Events instead, expose them via
`AirSim`'s `simRunConsoleCommand` (e.g. `ce Activate`) and update
`_activate_spray_actor` accordingly.

## Validation checklist

- [ ] All 8 actors named correctly (no spaces, zero-indexed).
- [ ] `Auto Activate` is OFF on the Particle System component.
- [ ] Particles invisible when the level starts.
- [ ] Calling `simSetObjectScale(name, (1,1,1))` makes them visible.
- [ ] Calling `simSetObjectScale(name, (0,0,0))` hides them.
